import 'package:flutter/material.dart';

class Practica1 extends StatefulWidget {
  const Practica1({Key? key}) : super(key: key);

  @override
  State<Practica1> createState() => _Practica1State();
}

class _Practica1State extends State<Practica1> {
  final Color myColor = Color(0xA5CFEFFF);
  bool _isTextFieldVisible = false;
  String _textFieldValue = '';
  String _nombre = 'espere al textfield y presione enter cuando coloque su nombre';
  ElevatedButton _otherButton = ElevatedButton(
    onPressed: () {},    style: ButtonStyle(backgroundColor: MaterialStateProperty.all<Color>(Colors.white),
  ),
  child: Text('estoy escondido', style: TextStyle(color:Color(0xACC7E5A5))),
  );


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Mi aplicación'),
        actions: [
          IconButton(
            icon: Icon(Icons.settings),
            onPressed: () {
              calificar();
            },
          ),
        ],
      ),
      body:ListView(
        children: [
          SizedBox(height: 100,),



          ElevatedButton(onPressed: () {
            // Cambiamos el color de fondo del otro botón
            setState(() {
              _otherButton = ElevatedButton(
                onPressed: () {setState(() {_isTextFieldVisible = true;});
                },
                style: ButtonStyle(backgroundColor: MaterialStateProperty.all<Color>(Colors.black),
              ),
                child: Text('Permiteme hacer visible un textfield presionandome', style: TextStyle(color:Color(0xACC7E5A5))),
              );
            });
          }, child: Text("presioname porfa")),
          SizedBox(height: 30,),
          ElevatedButton(onPressed: (){}, child: Text("Puedes realizar operaciones si me presionas"),
            style: ButtonStyle(backgroundColor: MaterialStateProperty.all<Color>(Colors.white),
          ),),
          _otherButton,
          //arriba los botones que cambian de color
          /////////////////////////////////////////////////////////////////////////////////////////////////
          //abajo textfield
          Visibility(
            visible: _isTextFieldVisible,
            child: TextField(onChanged: (value) {setState(() {_textFieldValue = value;});
              },  onSubmitted: (String value) {setState(() {_nombre ="apruebeme porfa profesor "+value+" prometo no ejercer :C";});
            },
              decoration: InputDecoration(hintText: 'Ingresa tu nombre',),
            ),
          ),
          Center(child:Text(_nombre,style:TextStyle(
            fontSize: 30),),),


        ],
      ),

    );

  }
  void calificar(){
    showDialog(context: context, builder: (BuildContext context){
      return AlertDialog(
        title: Text("Disclainer"),
        content: Text("Usted al presionar esto esta aceptando califcar con 100/100 el programa"),
        actions: [
          TextButton(onPressed: (){
            Navigator.of(context).pop();
          }, child: Text("OK acepto"))

        ],
      );//AlertDialog
    });//showDialog
  }
}
