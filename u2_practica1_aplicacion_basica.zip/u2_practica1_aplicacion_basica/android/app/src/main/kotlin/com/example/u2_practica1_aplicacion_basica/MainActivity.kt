package com.example.u2_practica1_aplicacion_basica

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
